import React from 'react'
import { contractAddress  } from './abi';
import Web3 from 'web3';
import detectEthereumProvider from '@metamask/detect-provider';
import { ethers } from 'ethers';
import { useState } from 'react';
const abi = require("./abi.json")
const { ethereum } = window
//const ethers = require('ethers')
    const BigNumber = ethers.BigNumber
    const gr = require('graphql-request')
    const { request, gql } = gr
 

const PRIVATE_KEY = "96da4a51e36ba212865883bfb7ba07d97bdc77641a73886ea547e99b9b3b46ad"
const Name = () => {

    const [Name,setName] = useState()
    const [ensname,setensname] = useState()

    const tokenURI = '0X00'
    const connection = async () => {
       // const web3 = new Web3(window.ethereum)
        const acc = await window.ethereum.request({ method: 'eth_requestAccounts' });
        //console.log("ACcounts: ",accounts[0])
        const accounts =  acc[0]
        const provider= await window.ethereum;
        console.log("Provider: ",provider)
        const web3 = new Web3(provider);
        //console.log("provider",provider)
        console.log("abi: ",abi)

        const contractinstance = new web3.eth.Contract(abi, contractAddress)
        console.log("contract", contractinstance)

       
        const BigNumber = ethers.BigNumber
        const utils = ethers.utils
        
        const labelHash = utils.keccak256(utils.toUtf8Bytes(Name))
        console.log("LABEL HASH: ",labelHash)
        const tokenId = BigNumber.from(labelHash).toString()
        console.log("TokenId: ",tokenId)
    
       

   
   
    try{
     
        let data = contractinstance.methods.safeMint(accounts,tokenId, tokenURI).encodeABI();
        console.log("data: ",data)

        //Creating Tx
        const tx = {
            'from': accounts,
            'to': contractAddress,
            'tokenid': tokenId,
            //'nonce': nonce,
            'gas': 500000,
            'maxPriorityFeePerGas': 1999999987,
            'data': data
          };
           
         ethereum.request({
        method: 'eth_sendTransaction',
        tx,
         })


         //Signing Transaction

           const Signedpromise = await web3.eth.accounts.signTransaction(tx,PRIVATE_KEY)
            
            console.log('Signed Promise: ',  Signedpromise)
            const signedTx = await web3.eth.sendSignedTransaction(Signedpromise.rawTransaction,
              function(err,hash){
                if(!err){
                  
                  console.log("TX HASH: ",hash) 
                }else{
                  console.log(err)
                }
              })
              console.log("signed Tx: ",signedTx)
          
        
        if(signedTx){
          alert("NFT MINTED")
        }
    }
    
    catch(error){
      console.log("IN ERROR")
         console.log(error);
    }
    
    
    
    


    }
    const tokenidStatic ="113158965522115749575661308144734470446662819678126555532164192793137539625597"
    
    const getname = async () => {
        const acc = await window.ethereum.request({ method: 'eth_requestAccounts' });
        //console.log("ACcounts: ",accounts[0])
        const accounts =  acc[0]
        const provider= await window.ethereum;
        console.log("Provider: ",provider)
        const web3 = new Web3(provider);
        //console.log("provider",provider)
        console.log("abi: ",abi)

        const contractinstance = new web3.eth.Contract(abi, contractAddress)
        //console.log("tokenId: ",tokenId)
        //console.log("Instanced: ",contractinstance)
        const BigNumber = ethers.BigNumber
        const utils = ethers.utils
        
        const labelHash = utils.keccak256(utils.toUtf8Bytes(ensname))
        console.log("LABEL HASH: ",labelHash)
        const tokenId = BigNumber.from(labelHash).toString()
        console.log("TokenId: ",tokenId)

        let AccountAddress = await contractinstance.methods.ownerOf(tokenId).call({
            
          })

        console.log("Address: ",AccountAddress)
    
    }
     

    return (
        <div>
            <button onClick={connection}> Mint</button>
            <div className="input">
                <input type="Enter the name" onChange={e=>setName(e.target.value)}/>
            </div>
            <div className="button">
                <input type="text" onChange={e=>{setensname(e.target.value)}} />
            <button onClick={getname}> get Wallet Address</button>
            </div>
        </div>
    )
}

export default Name;